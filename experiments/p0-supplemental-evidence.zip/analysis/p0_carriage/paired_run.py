#!/usr/bin/env python3
"""Fresh original/next-state P0 pairs, bounded synthesis and diagnostics."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
import threading
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'retry_obligation'))
from probe import parse, render, run

LABELS = {'2S': ('one-hot','S','no_pending'), '2SP': ('one-hot','S','with_pending'),
          '3S': ('enumerated','S','no_pending'), '3SP': ('enumerated','S','with_pending'),
          '2FP': ('one-hot','F','with_pending'), '3FP': ('enumerated','F','with_pending')}
ITEMS = ('snacks0','butter0','bread0','waste0','waste1','soda0')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--timeout', type=float, default=1200)
    ap.add_argument('--archive-root', type=Path,
                    help='Optional original experiment tree; defaults to bundled inputs')
    ap.add_argument('--slugs', type=Path, required=True)
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--compiler', type=Path, default=Path(__file__).with_name('production_compile.py').resolve())
    ap.add_argument('--jobs', type=int, default=2)
    args = ap.parse_args()
    if not 0 < args.timeout < float('inf'): ap.error('finite positive timeout required')
    if not 1 <= args.jobs <= 4: ap.error('jobs must be between 1 and 4')
    args.out.mkdir(parents=True, exist_ok=False)
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    summary = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
               'synthesis_timeout_s':args.timeout, 'diagnostic_timeout_s':120,
               'reorder_threshold':250, 'slugs_sha256':digest(args.slugs),
               'compiler_sha256':digest(args.compiler), 'compiler_mode':'production thorough', 'jobs':args.jobs, 'cases':{}}
    backend = (args.source_root / 'flexbe_synthesis_slugs/flexbe_synthesis_slugs'
               / 'helpers/structured_slugs_parser/compiler.py')
    summary['production_compiler_source']=str(backend)
    summary['production_compiler_sha256']=digest(backend)
    bundled = Path(__file__).with_name('paired-results')
    lock=threading.Lock()
    def save():
        with lock:
            temp=args.out/'summary.tmp'
            temp.write_text(json.dumps(summary,indent=2)+'\n')
            temp.replace(args.out/'summary.json')
    # Stage and validate all sources before launching expensive processes.
    for label in ['2S','2SP','3S','3SP','2FP','3FP','Full']:
        if label == 'Full':
            stem='pyrobosim__pyrobosim__p0_full_spec__full_spec__na__no_pending'
            filename='p0_full_spec'
        else:
            enc,live,pending=LABELS[label]
            filename='p0_capabilities' if enc=='one-hot' else 'p0_parsed'
            stem=f'pyrobosim__p0_capabilities__{filename}__{enc}__{live}__{pending}'
        if args.archive_root:
            base = args.archive_root / 'experiments/pyrobosim/runs/pyrobosim_stats/runs'
            source = (base / (stem + '__alphabetic__seednone__threshold_250') /
                      'trial_00/synthesis_byproducts' / f'{filename}.structuredslugs')
        else:
            source = bundled / f'{label}_original' / 'spec.structuredslugs'
        parts=parse(source.read_text())
        clauses=[line for line in parts['ENV_TRANS'] if line.strip().startswith('!(') and all(f'{x}=0' in line for x in ITEMS)]
        assert len(clauses)==6, (label,clauses)
        init={s.split('#',1)[0].strip() for s in parts['ENV_INIT']}
        initial_locations={x:next(int(s.split('=')[1]) for s in init if re.fullmatch(x+r'=\d+',s)) for x in ITEMS}
        assert all(v>0 for v in initial_locations.values())
        for variant in ['original','next_state']:
            name=label+'_'+variant; folder=args.out/name; folder.mkdir()
            changed=copy.deepcopy(parts)
            if variant=='next_state':
                changed['ENV_TRANS']=[re.sub(r'\b('+'|'.join(ITEMS)+r')\b',r"\1'",s) if s in clauses else s for s in parts['ENV_TRANS']]
            assert all(changed[k]==parts[k] for k in parts if k!='ENV_TRANS')
            spec=folder/'spec.structuredslugs'
            spec.write_text(source.read_text() if variant=='original' else render(changed))
            summary['cases'][name]={'source':str(source),'source_sha256':digest(source),
                'spec_sha256':digest(spec),'initial_item_locations':initial_locations,'state':'staged'}
    save()
    # Compile every case first; require every original to match archived clauses.
    clean=lambda text:[s.strip() for s in text.splitlines() if s.strip() and not s.lstrip().startswith('#')]
    for name,entry in summary['cases'].items():
        folder=args.out/name;spec=folder/'spec.structuredslugs'
        command = [sys.executable, str(args.compiler.resolve()), '--thoroughly',
                   '--source-root', str(args.source_root.resolve()), str(spec.resolve())]
        entry['compile'] = run(command, folder/'compile', 120)
        assert entry['compile']['returncode']==0, name
        compiled=folder/'spec.slugsin';compiled.write_bytes((folder/'compile.stdout').read_bytes())
        if name.endswith('_original'):
            archived=Path(entry['source']).with_suffix('.slugsin')
            entry['archive_compiled_sha256']=digest(archived)
            entry['compiled_matches_archive_clauses']=clean(archived.read_text())==clean(compiled.read_text())
            assert entry['compiled_matches_archive_clauses'], name
        entry['compiled_sha256']=digest(compiled)
        entry['state']='compiled'
    save()
    print('All seven original compiled specifications match archived declarations and clauses.',flush=True)
    def execute(item):
        name,entry=item;folder=args.out/name;compiled=folder/'spec.slugsin'
        print(time.strftime('%H:%M:%S'),name,'check/start synthesis',flush=True)
        diag=folder/'well_separation.json'
        entry['check']=run([str(args.slugs),'--reorder-threshold','250','--checkWellSeparation','--minimizeWellSeparationCore','--jsonOutput',str(compiled.resolve()),str(diag.resolve())],folder/'check',120)
        if entry['check']['returncode']==0 and diag.exists():
            data=json.loads(diag.read_text());entry['well_separation']={k:data.get(k) for k in ['status','complete','cases','core_complete','core_assumptions']}
        entry['state']='synthesizing';save()
        entry['synthesis']=run([str(args.slugs),'--reorder-threshold','250','--explicitStrategy','--jsonOutput',str(compiled.resolve())],folder/'synthesis',args.timeout)
        entry['verdict']='unknown'
        if entry['synthesis']['returncode']==0:
            log=(folder/'synthesis.stderr').read_text()
            m=re.search(r'Specification is (unrealizable|realizable)',log)
            if m: entry['verdict']=m[1]
            if entry['verdict']=='realizable':
                raw=json.loads((folder/'synthesis.stdout').read_text());entry['extracted_states']=len(raw['nodes'])
        entry['state']='finished';save()
        print(time.strftime('%H:%M:%S'),name,entry['verdict'],entry['synthesis']['seconds'],flush=True)
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        list(pool.map(execute,summary['cases'].items()))
    return 0 if all(e.get('verdict')!='unknown' and e.get('well_separation',{}).get('complete') for e in summary['cases'].values()) else 1


if __name__=='__main__': raise SystemExit(main())
