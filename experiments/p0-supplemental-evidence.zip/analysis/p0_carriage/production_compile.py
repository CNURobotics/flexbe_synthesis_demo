#!/usr/bin/env python3
"""CLI adapter for the workspace compiler, using the pipeline's thorough mode."""
import argparse
from pathlib import Path
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--thoroughly',action='store_true',required=True)
p.add_argument('spec',type=Path)
p.add_argument('--source-root',type=Path,required=True)
a=p.parse_args()
sys.path.insert(0,str(a.source_root/'flexbe_synthesis_slugs'))
from flexbe_synthesis_slugs.helpers.structured_slugs_parser import compiler
compiler.performConversion(str(a.spec),thoroughly=True,fout=sys.stdout)
