#!/usr/bin/env python3
"""Compare paired extractions, audits and reduced representations."""
import argparse
from collections import deque
import json
from pathlib import Path


def trace_compare(a,b,initial_a,initial_b,outputs,ignore_pending=False):
    """Compare rooted deterministic full-input/output behavior; no GR(1) proof."""
    if a['variables']!=b['variables']:return {'status':'unsupported','reason':'variable order differs'}
    variables=a['variables']; output_indices=[i for i,v in enumerate(variables) if v in outputs and not (ignore_pending and v.endswith('_p'))]
    input_indices=[i for i,v in enumerate(variables) if v not in outputs]
    def edges(g,n):
        result={}
        for t in g['nodes'][n]['trans']:
            t=str(t); key=tuple(g['nodes'][t]['state'][i] for i in input_indices)
            if key in result and result[key]!=t:raise ValueError('Nonunique successor for full input valuation')
            result[key]=t
        return result
    queue=deque([(initial_a,initial_b)]);seen=set()
    while queue:
        x,y=queue.popleft()
        if (x,y) in seen:continue
        seen.add((x,y))
        if [a['nodes'][x]['state'][i] for i in output_indices]!=[b['nodes'][y]['state'][i] for i in output_indices]:
            return {'status':'different','reason':'output valuation','state_pair':[x,y],'product_states_checked':len(seen)}
        try: ea,eb=edges(a,x),edges(b,y)
        except ValueError as e:return {'status':'unsupported','reason':str(e)}
        if ea.keys()!=eb.keys():return {'status':'different','reason':'admitted full-input valuations','state_pair':[x,y],'product_states_checked':len(seen)}
        queue.extend((ea[k],eb[k]) for k in ea)
    return {'status':'equal','product_states_checked':len(seen)}


def stripped_reduced(data):
    # Strict serialized representation comparison: exclude bookkeeping, not semantics.
    return {'input_variables':data['input_variables'],'output_variables':data['output_variables'],
            'automaton':sorted([{k:v for k,v in s.items() if k not in ('rank','incoming')} for s in data['automaton']],key=lambda s:s['name'])}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=Path,required=True);a=p.parse_args()
    root=a.directory;summary=json.loads((root/'summary.json').read_text());report={}
    for label in ['2S','2SP','3S','3SP','2FP','3FP','Full']:
        folders=[root/(label+'_'+v) for v in ['original','next_state']]
        if not all((f/'analysis.json').exists() for f in folders):continue
        analyses=[json.loads((f/'analysis.json').read_text()) for f in folders]
        raw=[json.loads((f/'synthesis.stdout').read_text()) for f in folders]
        compiled=(folders[0]/'spec.slugsin').read_text().split('[OUTPUT]')[1].split('[',1)[0]
        outputs={s.strip() for s in compiled.splitlines() if s.strip() and not s.startswith('#')}
        result={}
        for variant,folder,analysis in zip(['original','next_state'],folders,analyses):
            run=summary['cases'][label+'_'+variant]
            result[variant]={'realizability':run['verdict'],'well_separation':run['well_separation'],
                             'synthesis_seconds':run['synthesis']['seconds'],
                             **{k:analysis.get(k) for k in ['extracted_states','reduced_states','audit_original','audit_reduced','reduction_skipped']}}
        result['raw_json_equal']=raw[0]==raw[1]
        result['raw_valuations_and_edges_equal']=(raw[0]['variables']==raw[1]['variables'] and
            {n:{k:v for k,v in rec.items() if k!='rank'} for n,rec in raw[0]['nodes'].items()}==
            {n:{k:v for k,v in rec.items() if k!='rank'} for n,rec in raw[1]['nodes'].items()})
        for ignore,key in [(False,'rooted_full_output_behavior'),(True,'rooted_core_output_behavior')]:
            result[key]=trace_compare(*raw,analyses[0]['initial_state'],analyses[1]['initial_state'],outputs,ignore)
        if all((f/'reduced.json').exists() for f in folders):
            result['reduced_representation_equal_ignoring_rank_incoming']=stripped_reduced(json.loads((folders[0]/'reduced.json').read_text()))==stripped_reduced(json.loads((folders[1]/'reduced.json').read_text()))
        report[label]=result
    (root/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    for label,r in report.items():
        print(label,[(r[v]['realizability'],r[v]['well_separation']['status'],r[v]['extracted_states'],r[v]['reduced_states'],r[v]['audit_original']['failure_kind']) for v in ['original','next_state']],r['rooted_core_output_behavior'],flush=True)


if __name__=='__main__':main()
