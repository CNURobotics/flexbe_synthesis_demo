"""Small counterexamples for the rooted full-input strategy comparison."""
import unittest
from compare_pairs import trace_compare


def graph(nodes):
    return {'variables':['i','a','a_p'],'nodes':nodes}


def node(i,a,p,edges):return {'state':[i,a,p],'trans':edges,'rank':0}


class ComparisonTests(unittest.TestCase):
    def test_renamed_and_duplicated_memory_states(self):
        a=graph({'0':node(0,1,0,['1']),'1':node(1,0,0,['1'])})
        b=graph({'x':node(0,1,0,['y']),'y':node(1,0,0,['z']),'z':node(1,0,0,['z'])})
        self.assertEqual(trace_compare(a,b,'0','x',{'a','a_p'})['status'],'equal')

    def test_changed_output(self):
        a=graph({'0':node(0,1,0,['0'])});b=graph({'0':node(0,0,0,['0'])})
        self.assertEqual(trace_compare(a,b,'0','0',{'a','a_p'})['reason'],'output valuation')

    def test_different_admitted_input(self):
        a=graph({'0':node(0,1,0,['0'])});b=graph({'0':node(1,1,0,['0'])})
        self.assertEqual(trace_compare(a,b,'0','0',{'a','a_p'})['reason'],'admitted full-input valuations')

    def test_pending_mask_is_explicit(self):
        a=graph({'0':node(0,1,0,['0'])});b=graph({'0':node(0,1,1,['0'])})
        self.assertEqual(trace_compare(a,b,'0','0',{'a','a_p'})['status'],'different')
        self.assertEqual(trace_compare(a,b,'0','0',{'a','a_p'},True)['status'],'equal')

    def test_nondeterministic_input_is_not_silently_collapsed(self):
        a=graph({'0':node(0,1,0,['1','2']),'1':node(1,0,0,['1']),'2':node(1,0,0,['2'])})
        self.assertEqual(trace_compare(a,a,'0','0',{'a','a_p'})['status'],'unsupported')


if __name__=='__main__':unittest.main()
