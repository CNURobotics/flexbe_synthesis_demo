# P0 carriage exclusions in paired synthesis runs

The seven configurations are 2S, 2SP, 3S, 3SP, 2FP, 3FP and Full. Each pair
uses the archived alphabetic declaration order with CUDD threshold 250, one
fresh original and one fresh next-state-carriage run. Only the six carriage
clauses in ENV_TRANS change. All seven ENV_INIT sections explicitly place
all six items at nonzero locations; the script verifies this before synthesis.
The original structured inputs match the archived inputs byte-for-byte. The
production compiler runs with `thoroughly=True`, matching the synthesis
pipeline. Before synthesis, all seven recompiled originals matched the archived
declarations and clauses after removing comments and blank lines.

## Inspect the saved results

[The paired comparison](paired-results/comparison.json) summarizes the results
from the saved specifications, strategies, and audits. To regenerate it with
Python alone, run from the directory containing `p0_carriage/` and
`retry_obligation/`.

```sh
replay_dir=$(mktemp -d)
cp -R p0_carriage/paired-results/. "$replay_dir/"
python3 p0_carriage/compare_pairs.py --directory "$replay_dir"
```

## Rerun synthesis and auditing

Use a sourced ROS 2 workspace with the built `flexbe_synthesis_msgs` package
and the FlexBE synthesis source checkout. The analysis replay was verified
with ROS 2 Kilted, Python 3.12.3, and PyYAML 6.0.1. Use the Slugs fork and build
that support the well-separation and core-minimization options recorded in
[the run summary](paired-results/summary.json).

The bundle includes the original structured and compiled inputs and the
capability metadata used for auditing. Run from the extracted archive's
`analysis/` directory. Set `FLEXBE_SYNTHESIS_ROOT` to the FlexBE synthesis
checkout in your sourced ROS workspace and `SLUGS_BIN` to the compiled solver.
Use a fresh output directory.

```sh
paired_dir="$(mktemp -d)/paired"
python3 p0_carriage/paired_run.py --out "$paired_dir" --jobs 2 \
  --source-root "$FLEXBE_SYNTHESIS_ROOT" --slugs "$SLUGS_BIN"
python3 p0_carriage/analyze_batch.py --directory "$paired_dir" \
  --source-root "$FLEXBE_SYNTHESIS_ROOT"
```

`--archive-root` can select an alternate original experiment tree.
`--metadata-root` can select alternate capability metadata for the analyzer.
The bundled inputs and metadata are the defaults.

Alternatively, run the second command with `--watch` in another terminal while
the first is still running. Do not run two analysis watchers on the same folder.
Choose a new synthesis output directory. The batch uses two concurrent solver
jobs with a 1,200-second timeout per run. Compilation, well-separation checking
with core minimization, and analysis each have a 120-second subprocess timeout.
Each audit has a 60-second budget. A synthesis timeout yields an unknown
verdict. The workflow ends with reduction and its audit.

## Implementation and comparisons

`analyze_strategy.py` imports the active ROS workspace's production
`SlugsSynthesizerHelper`, `StrategyAuditor`, and `SlugsSMReducer`. It uses the
archived one-hot, parsed/enumerated, or Full capability metadata as appropriate.
Full's metadata includes unused capabilities; it is retained intact, with every
actual activation checked against that metadata. Parsed action-index comments
are retained so the production auditor derives its activation map.

Production decoding expands integer variables and uses the first root with
outgoing transitions as initial, just as the pipeline does. Original audit
results retain all warnings. Only a complete valid original audit permits
reduction; failed/incomplete originals have no claimed reduced strategy.
Stopping after a failed audit matches the pipeline. Withholding reduction after
an incomplete audit is an additional conservative analysis policy; the current
production manager permits incomplete-audit continuation.
Reduced audits have protocol enforcement disabled by the production auditor;
those warnings are retained, not presented as strict raw-protocol validation.
Source and metadata hashes accompany each analysis.

`adapter-validation.json` records checks against existing archived strategies:
one-hot 2S and enumerated 3S each pass and reduce to 19 states; Full passes and
reduces to 66. These are adapter checks, not new synthesis results.

`compare_pairs.py` reports:

- Exact raw JSON equality, and equality of state valuations/transitions with
  rank annotations ignored (both include the original node identifiers).
- Rooted deterministic full-input/output behavior via exhaustive traversal of
  the product of the two extracted graphs. This ignores node names and ranks;
  both the admitted next-input valuations and the outputs must agree. A second
  comparison masks pending outputs only, matching the reducer's core-output
  convention. Nonunique successors for a full input are reported unsupported,
  not collapsed. These compare the selected extracted strategies, not all
  strategies of the synthesis games or a fairness-aware progress property.
- Strict reduced-representation equality excluding ranks and incoming-edge
  bookkeeping, but retaining node identifiers and representative valuations.
  A difference here is not itself proof of behavioral inequivalence; consult
  the separate rooted behavior comparison.

The five comparison tests cover renamed/duplicated memory states, changed
outputs, changed input support, the explicit pending mask, and nondeterministic
successors:

```sh
python3 -m unittest discover -s p0_carriage -p test_comparison.py
```

## Compiler-mode correction

The earlier [diagnostic-only probe](README.md) and a preliminary synthesis
batch used the standalone compiler without thorough mode. This mode omitted
current-state integer-range clauses present in the archived compiled inputs.
The preliminary batch completed six pairs before the Full pair was
interrupted. The results below all use the production compiler.

The corrected batch uses `production_compile.py`, which calls the active
workspace compiler exactly as the pipeline does, with `thoroughly=True`.
Both members of every pair use the same production compilation mode. All seven
originals are verified against archived compiled clauses before execution.
Two solver jobs run concurrently to reduce turnaround; these single-run wall
times are descriptive only and support no performance claim.

## Results — completed October 28, 2026

All **14 production-mode runs** completed and were realizable; all diagnostics,
core minimizations, and invoked audits completed. Each of the seven fresh
original strategies exactly matches its archived strategy JSON. Within every
original/next-state pair, the parsed raw JSON is identical, **including ranks**.
The five pairs passing the original audit also have identical reduced
representations (excluding rank/incoming bookkeeping), with matching successful
reduced audits. The two trap-failing pairs stop before reduction, as in the
production pipeline.

| Configuration | Original diagnostic | Next-state diagnostic | Extracted states, each | Reduced states, each | Original-audit verdict, both |
|---|---|---|---:|---:|---|
| 2S | P-reach/E-safe | Well-separated | 47 | 19 | Pass |
| 2SP | P-reach/E-safe | Well-separated | 47 | 19 | Pass |
| 3S | P-reach/E-safe | Well-separated | 38 | 19 | Pass |
| 3SP | P-reach/E-safe | Well-separated | 38 | 19 | Pass |
| 2FP | P-reach/E-safe + P-all/E-just | P-all/E-just | 108 | Not run: raw audit fails | GOAL_UNREACHABLE_TRAP |
| 3FP | P-reach/E-safe + P-all/E-just | P-all/E-just | 84 | Not run: raw audit fails | GOAL_UNREACHABLE_TRAP |
| Full | P-reach/E-safe | Well-separated | 116 | 66 | Pass |

All raw audits have no warnings and retain strict protocol checking. Successful
reduced audits retain the production auditor's two expected protocol-disabled
warnings, as explained above. No audit timed out. Exact raw JSON equality also
preserves the illustrated 2FP move-pending trap; the carriage reformulation does
not repair the pending-justice failure in either Fair-Outcome configuration.

The rooted full-input/output comparisons also agree for every pair, both with
all outputs and with pending outputs masked.

## Interpretation and scope

For these seven alphabetic, threshold-250 configurations, the next-state
formulation eliminates the carriage-related safety diagnosis without changing
the extracted controllers or audit verdicts. Full and all four System-Goal
variants become well-separated. Both Fair-Outcome-with-pending variants retain
`P-all/E-just` and the same trap-failing strategies. The well-separation
diagnostic is a property of the specification. The trap verdict comes from
the separate audit of the extracted strategy.

The initialization premise is checked, not assumed: in every input specification,
`bread0=4`, `butter0=5`, `snacks0=4`, `soda0=5`, `waste0=7`, and `waste1=6`.
Thus ENV_INIT already excludes multiple carriage. For the carriage invariant I,
`G I` and `G X I` impose the same invariant on infinite traces from these initial
states. Their transition-level diagnostic reachability differs, as the original
probe explains. The present selected-strategy identity is empirical evidence,
not a proof that every synthesis-game behavior or every ordering is unchanged.

The comparison covers these seven configurations at one declaration ordering.
The modeling result applies to the tested P0 carriage exclusions with the
invariant already enforced by initialization.

## Timing and artifacts

The corrected batch took approximately **51.3 minutes** with two concurrent solver jobs. Summed individual synthesis wall times were 100.5 minutes. These are single-run observations under concurrency, not performance comparisons. The preliminary batch and compiler correction added separate elapsed work.

| Configuration | Original synthesis (s) | Next-state synthesis (s) |
|---|---:|---:|
| 2S | 798.766 | 937.972 |
| 2SP | 666.188 | 96.709 |
| 3S | 424.067 | 306.398 |
| 3SP | 139.568 | 450.748 |
| 2FP | 235.620 | 167.865 |
| 3FP | 485.550 | 349.212 |
| Full | 451.342 | 517.486 |

`paired-results/` contains compiled/structured inputs, raw extractions, complete
logs, NWS diagnostics/cores, decoded graphs, audits, and eligible reduced graphs.
`summary.json` records commands, limits, hashes and archive-clause matches;
`comparison.json` records paired outcomes; `validation.json` confirms all 14
processes, all seven exact six-clause interventions, and archived-strategy matches.
`analysis_processes.json` records bounded analysis-subprocess completion.
The archived command and source records use placeholders for machine-specific
directory prefixes.
