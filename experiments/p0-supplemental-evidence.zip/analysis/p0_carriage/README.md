# P0 carriage-assumption diagnostic

This two-configuration probe of the PyRoboSim P0 model tests whether changing
the timing of the carriage exclusions separates the safety and justice findings
in the non-well-separation (NWS) diagnostic. The
[seven-configuration follow-up](PAIRED_RUNS.md) uses the production compiler
and adds strategy extraction and auditing.

## Reproduce

Run from the directory containing `p0_carriage/` and `retry_obligation/`.
Set `SLUGS_ROOT` to the Slugs checkout used to build the solver. The
probe uses the original inputs bundled in `paired-results/`.

```sh
python3 p0_carriage/probe.py --out /tmp/p0-carriage-new-results \
  --slugs "$SLUGS_ROOT/src/slugs" \
  --compiler "$SLUGS_ROOT/tools/StructuredSlugsParser/compiler.py"
```

The output directory must be new. The probe uses the alphabetic archive inputs
and CUDD threshold 250. Each subprocess has a 30-second timeout. It runs
compilation and `--checkWellSeparation --minimizeWellSeparationCore --jsonOutput`.
The standalone compiler runs without thorough mode.

## Exact intervention

Two saved one-hot configurations: System-Goal/no-pending **2S** and
Fair-Outcome/with-pending **2FP**. Item locations are environment inputs;
location zero means carried. There are six current-state ENV_TRANS clauses,
one centered on each item, jointly prohibiting two carried items. For example:

```
!(snacks0=0 & (butter0=0|bread0=0|waste0=0|waste1=0|soda0=0))
```

Variants:

- `original`: archived source copied byte-for-byte.
- `remove_one`: delete only the snacks-centered clause returned by the original
  minimized core. Other clauses still forbid the same pairs.
- `remove_all`: delete all six carriage clauses. This is an ablation, not a
  proposed physical model; it removes their explicit environment obligation.
- `next_state`: keep all six clauses in **ENV_TRANS**, but prime every item
  location in them. For example:

```
!(snacks0'=0 & (butter0'=0|bread0'=0|waste0'=0|waste1'=0|soda0'=0))
```

All other sections, including SYS_TRANS grab preconditions and both liveness
sections, remain unchanged (asserted by the script). No assumption moves to SYS.

## Results

All eight checks and core minimizations completed. Individual checks took
approximately 1.5–2.6 seconds; timings are descriptive, not a benchmark.

| Variant | P0 2S | P0 2FP |
|---|---|---|
| Original | NWS: P-reach/E-safe | NWS: P-reach/E-safe + P-all/E-just |
| Remove one | NWS: P-reach/E-safe | NWS: P-reach/E-safe + P-all/E-just |
| Remove all six | Well-separated | NWS: P-all/E-just |
| All six on next state | Well-separated | NWS: P-all/E-just |

The remove-one core switches to the butter-centered carriage clause. In both
2FP remove-all and next-state variants, the minimized core instead contains:

```
!place_item_a -> !place_item_c'       # ENV_TRANS
(!place_item_p) | place_item_c'      # ENV_LIVENESS (implicit GF)
```

These clauses diagnose justice at the specification level. The
[paired synthesis comparison](PAIRED_RUNS.md)
checks the move-pending trap in the extracted strategies.

## Interpretation and limits

Changing the six invariants' timing eliminates the observed safety finding in
both configurations. The separate pending-justice finding persists in 2FP.
Deleting a single minimized-core clause leaves the same pairs constrained by
the remaining clauses.

The timing distinction matters to diagnostic reachability: a current-state
invariant permits a transition into a bad state, then permits no continuation
from that state. A next-state invariant rules out that transition. With the
existing outcome rules, an invalid second grab can be answered with failure
instead of successful acquisition of another item.

The carriage clauses remain environment assumptions. The archived ENV_INIT
satisfies the carriage invariant I, so `G I` and `G X I` impose the same
invariant on infinite traces from those initial states. The diagnostics examine
transition admissibility and finite reachability with system guarantees removed.
The trace argument concerns the invariant alone.

The command generates all eight structured and compiled specifications,
diagnostic JSON with minimized cores, compiler and checker logs, and
`summary.json` with input and tool hashes, commands, time limits, and verdicts.
