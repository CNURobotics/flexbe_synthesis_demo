#!/usr/bin/env python3
"""Analyze completed paired runs; --watch follows a running paired_run.py batch."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'retry_obligation'))
from probe import run


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,required=True)
    p.add_argument('--watch',action='store_true')
    p.add_argument('--source-root', type=Path, required=True)
    p.add_argument('--metadata-root', type=Path,
                   default=Path(__file__).with_name('capability-metadata'))
    args=p.parse_args();folder=args.directory
    attempted={};start=time.monotonic()
    while True:
        try: summary=json.loads((folder/'summary.json').read_text())
        except (FileNotFoundError,json.JSONDecodeError):
            if not args.watch:raise
            time.sleep(2);continue
        for name,entry in summary['cases'].items():
            if entry.get('state')!='finished' or entry.get('verdict')!='realizable' or name in attempted:continue
            directory=folder/name
            command = [
                sys.executable, str(Path(__file__).with_name('analyze_strategy.py').resolve()),
                '--directory', str(directory.resolve()), '--label', name.split('_')[0],
                '--source-root', str(args.source_root.resolve()),
                '--metadata-root', str(args.metadata_root.resolve()),
            ]
            result = run(command, directory/'analysis_process', 120)
            attempted[name]=result
            print(name,'analysis',result['status'],result['returncode'],flush=True)
            (folder/'analysis_processes.json').write_text(json.dumps(attempted,indent=2)+'\n')
            subprocess.run([sys.executable,str(Path(__file__).with_name('compare_pairs.py')),'--directory',str(folder)],check=True)
        done=all(e.get('state') in ('finished','compile_failed') for e in summary['cases'].values())
        if done or not args.watch:break
        if time.monotonic()-start>6*3600:raise TimeoutError('Six-hour batch monitoring limit exceeded')
        time.sleep(2)
    return 0 if all(e['returncode']==0 for e in attempted.values()) else 1


if __name__=='__main__':raise SystemExit(main())
