#!/usr/bin/env python3
"""Use the active production decoder, auditor and reducer on a saved extraction."""
import argparse
import hashlib
import inspect
import json
import re
from pathlib import Path
import sys
import time
import yaml
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'retry_obligation'))
from probe import parse


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,required=True)
    p.add_argument('--label',choices=['2S','2SP','3S','3SP','2FP','3FP','Full'],required=True)
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--metadata-root',type=Path,default=Path(__file__).with_name('capability-metadata'))
    args=p.parse_args()
    for pkg in ['flexbe_synthesis_core','flexbe_synthesis_slugs']:
        sys.path.insert(0,str(args.source_root/pkg))
    from flexbe_synthesis_msgs.msg import SynthesisErrorCode
    from flexbe_synthesis_slugs.helpers.slugs_synthesizer_helper import SlugsSynthesizerHelper
    from flexbe_synthesis_slugs.helpers.slugs_automaton import SlugsAutomaton
    from flexbe_synthesis_slugs.helpers.strategy_auditor import StrategyAuditor, derive_config
    from flexbe_synthesis_slugs.processes.slugs_sm_reducer import SlugsSMReducer
    folder=args.directory
    demo='p0_full_spec_demo' if args.label=='Full' else ('p0_capabilities_parsed_demo' if args.label.startswith('3') else 'p0_capabilities_demo')
    cap_path=args.metadata_root/demo/'configs'/f'{demo}_system_capabilities.yaml'
    caps=yaml.safe_load(cap_path.read_text())
    spec=parse((folder/'spec.structuredslugs').read_text())
    raw=json.loads((folder/'synthesis.stdout').read_text())
    clean=lambda lines:[s.strip() for s in lines if s.strip() and not s.lstrip().startswith('#')]
    helper=SlugsSynthesizerHelper(str(folder/'decoder'),caps['transition_outcomes'],['finished'],verbose=False,show_slugs_output=False)
    inputs,outputs=clean(spec['INPUT']),clean(spec['OUTPUT'])
    automaton=helper.gen_slugs_automaton_from_json(str(folder/'synthesis.stdout'),inputs,outputs).to_dict()
    assert [re.sub(r'(@0)\.\d+\.\d+$', r'\1', v) for v in raw['variables']]==automaton['input_variables']+automaton['output_variables'], 'variable-order mismatch'
    initial=[s['name'] for s in automaton['automaton'] if s['is_initial']]
    assert len(initial)==1
    payload={'env_trans':spec['ENV_TRANS'],'sys_props':spec['OUTPUT']}
    config=derive_config(caps,{},payload,['finished'])
    if args.label.startswith('3'):
        assert config.encoding=='parsed_capability'
        assert set(config.activation_map.values())==set(caps['capabilities'])-{'begin_game'}
    else:
        assert {x for x in outputs if x.endswith('_a')} <= {n+'_a' for n in caps['capabilities']}
    write=lambda name,obj:(folder/name).write_text(json.dumps(obj,indent=2)+'\n')
    write('decoded.json',automaton)
    start=time.monotonic()
    audit=StrategyAuditor(timeout_s=60).audit(automaton,str(folder/'spec.slugsin'),caps,{},payload,['finished'])
    write('audit_original.json',audit)
    summary={'initial_state':initial[0],'extracted_states':len(raw['nodes']),
             'audit_original':{k:audit.get(k) for k in ['valid','incomplete','failure_kind','warnings']},
             'audit_original_seconds':time.monotonic()-start,'encoding':config.encoding,
             'activation_map':config.activation_map,'capabilities_source':str(cap_path),
             'capabilities_sha256':hashlib.sha256(cap_path.read_bytes()).hexdigest(),
             'implementation_sources':{}}
    for cls in [SlugsSynthesizerHelper,SlugsAutomaton,StrategyAuditor,SlugsSMReducer]:
        source=Path(inspect.getfile(cls));summary['implementation_sources'][str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
    # Match the production stop on a failed audit. This analysis also withholds
    # reduction for an incomplete audit; production currently permits continuation.
    if audit.get('valid') and not audit.get('incomplete'):
        start=time.monotonic()
        reduced,error=SlugsSMReducer(name='CarriageAnalysisReducer',synthesized_automaton=automaton).process()
        assert error.value==SynthesisErrorCode.SUCCESS, error
        write('reduced.json',reduced)
        summary['reduction_seconds']=time.monotonic()-start
        summary['reduced_states']=len(reduced['automaton'])
        start=time.monotonic()
        audit2=StrategyAuditor(timeout_s=60).audit(reduced,str(folder/'spec.slugsin'),caps,{},payload,['finished'])
        write('audit_reduced.json',audit2)
        summary['audit_reduced']={k:audit2.get(k) for k in ['valid','incomplete','failure_kind','warnings']}
        summary['audit_reduced_seconds']=time.monotonic()-start
    else:
        summary['reduction_skipped']=('Analysis withholds reduction after an incomplete audit; production may continue.'
            if audit.get('incomplete') else 'Original audit failed; matches pipeline gate.')
    write('analysis.json',summary)
    print(json.dumps(summary,indent=2))
    return 1 if audit.get('incomplete') or audit.get('failure_kind')=='PARSE_ERROR' else 0


if __name__=='__main__':raise SystemExit(main())
