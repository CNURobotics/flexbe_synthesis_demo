#!/usr/bin/env python3
"""Bounded P0 carriage-assumption diagnostic; never edits archived inputs."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'retry_obligation'))
from probe import parse, render, run


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--timeout', type=float, default=30)
    p.add_argument('--archive-root', type=Path,
                   help='Optional original experiment tree; defaults to bundled inputs')
    p.add_argument('--slugs', type=Path, required=True)
    p.add_argument('--compiler', type=Path, required=True)
    args = p.parse_args()
    if not 0 < args.timeout < float('inf'):
        p.error('timeout must be finite and positive')
    args.out.mkdir(parents=True, exist_ok=False)
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    summary = {'timeout_seconds': args.timeout, 'reorder_threshold': 250,
               'slugs_sha256': digest(args.slugs), 'compiler_sha256': digest(args.compiler), 'cases': {}}
    bundled = Path(__file__).with_name('paired-results')
    items = ('snacks0', 'butter0', 'bread0', 'waste0', 'waste1', 'soda0')
    for label, suffix in [('2S', 'S__no_pending'), ('2FP', 'F__with_pending')]:
        if args.archive_root:
            base = args.archive_root / 'experiments/pyrobosim/runs/pyrobosim_stats/runs'
            trial = f'pyrobosim__p0_capabilities__p0_capabilities__one-hot__{suffix}__alphabetic__seednone__threshold_250'
            source = base / trial / 'trial_00/synthesis_byproducts/p0_capabilities.structuredslugs'
        else:
            source = bundled / f'{label}_original' / 'spec.structuredslugs'
        original = source.read_text()
        parts = parse(original)
        clauses = [line for line in parts['ENV_TRANS'] if line.strip().startswith('!(') and all(f'{item}=0' in line for item in items)]
        assert len(clauses) == 6, clauses
        assert clauses[0].startswith('!(snacks0=0 & ')
        for variant in ('original', 'remove_one', 'remove_all', 'next_state'):
            name = f'{label}_{variant}'
            directory = args.out / name
            directory.mkdir()
            changed = copy.deepcopy(parts)
            if variant == 'remove_one':
                changed['ENV_TRANS'].remove(clauses[0])
            elif variant == 'remove_all':
                changed['ENV_TRANS'] = [line for line in changed['ENV_TRANS'] if line not in clauses]
            elif variant == 'next_state':
                changed['ENV_TRANS'] = [re.sub(r'\b(' + '|'.join(items) + r')\b', r"\1'", line) if line in clauses else line for line in changed['ENV_TRANS']]
            assert all(changed[k] == parts[k] for k in parts if k != 'ENV_TRANS')
            spec = directory / 'spec.structuredslugs'
            spec.write_text(original if variant == 'original' else render(changed))
            entry = {'source': str(source), 'source_sha256': digest(source), 'spec_sha256': digest(spec), 'original_carriage_clauses': clauses}
            summary['cases'][name] = entry
            entry['compile'] = run([sys.executable, str(args.compiler), str(spec.resolve())], directory / 'compile', args.timeout)
            if entry['compile']['returncode'] == 0:
                compiled = directory / 'spec.slugsin'
                compiled.write_bytes((directory / 'compile.stdout').read_bytes())
                diagnostic = directory / 'well_separation.json'
                entry['check'] = run([str(args.slugs), '--reorder-threshold', '250', '--checkWellSeparation', '--minimizeWellSeparationCore', '--jsonOutput', str(compiled.resolve()), str(diagnostic.resolve())], directory / 'check', args.timeout)
                if entry['check']['returncode'] == 0 and diagnostic.exists():
                    data = json.loads(diagnostic.read_text())
                    entry['status'] = data.get('status')
                    entry['complete'] = data.get('complete')
                    entry['cases'] = data.get('cases')
            print(name, entry.get('status', 'UNKNOWN'), entry.get('cases', []), flush=True)
            (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return 0 if all(e.get('complete') for e in summary['cases'].values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
