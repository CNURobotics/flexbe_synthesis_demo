#!/usr/bin/env python3
"""Bounded, standalone Slugs probe; never modifies archived specifications."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

SECTIONS = ('INPUT', 'OUTPUT', 'ENV_INIT', 'SYS_INIT', 'ENV_TRANS',
            'SYS_TRANS', 'ENV_LIVENESS', 'SYS_LIVENESS')


def parse(text):
    parts = {key: [] for key in SECTIONS}
    current = None
    for line in text.splitlines():
        match = re.fullmatch(r'\[([A-Z_]+)\]', line.strip())
        if match:
            current = match[1]
            if current not in parts:
                raise ValueError(f'Unsupported section {current}')
        elif current:
            parts[current].append(line)
        elif line.strip() and not line.lstrip().startswith('#'):
            raise ValueError('Unexpected text before first section')
    return parts


def render(parts):
    return '\n\n'.join(f'[{key}]\n' + '\n'.join(parts[key]) for key in SECTIONS) + '\n'


def toy(retry=False, abandon=False, justice=True):
    # One attempt initially active. Completion is environment-controlled and
    # activation-gated; pending persists until completion. Goal persists.
    parts = parse('''[INPUT]
c
[OUTPUT]
a
p
g
[ENV_INIT]
!c
[SYS_INIT]
a
p
!g
[ENV_TRANS]
c' -> a
[SYS_TRANS]
p' <-> (a' | (p & !c'))
g' <-> (g | c')
[ENV_LIVENESS]
(!p | c')
[SYS_LIVENESS]
g
''')
    if retry:
        parts['SYS_LIVENESS'].append('(!p | a)')
    if abandon:
        parts['SYS_TRANS'].append("!a'")
    if not justice:
        parts['ENV_LIVENESS'] = []
    return render(parts)


def run(command, stem, timeout):
    start = time.monotonic()
    with stem.with_suffix('.stdout').open('wb') as out, stem.with_suffix('.stderr').open('wb') as err:
        try:
            result = subprocess.run(command, stdout=out, stderr=err, timeout=timeout, check=False)
            status, code = 'finished', result.returncode
        except subprocess.TimeoutExpired:
            status, code = 'timeout', None
    return {'command': command, 'status': status, 'returncode': code,
            'seconds': round(time.monotonic() - start, 3)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--slugs', type=Path, required=True)
    parser.add_argument('--compiler', type=Path, required=True)
    parser.add_argument('--case', choices=['p0-2fp'], help='Named archived case; includes strict strategy audit')
    parser.add_argument('--archive-root', type=Path,
                        help='Optional original experiment tree for the named case')
    parser.add_argument('--auditor-root', type=Path,
                        help='FlexBE synthesis checkout required by the named case')
    parser.add_argument('--spec', type=Path, help='Optional ONE archived structuredslugs spec')
    parser.add_argument('--pair', action='append', default=[], metavar='PENDING=ACTIVATION',
                        help='Explicit pending proposition and activation expression; repeat per capability')
    parser.add_argument('--timeout', type=float, default=30, help='Seconds per subprocess (default: 30)')
    parser.add_argument('--out', type=Path, required=True, help='New output directory; must not exist')
    args = parser.parse_args()
    if args.case:
        if args.spec or args.pair:
            parser.error('--case cannot be combined with --spec/--pair')
        if args.auditor_root is None or not args.auditor_root.is_dir():
            parser.error('Named case requires --auditor-root pointing to the FlexBE synthesis checkout')
        capability_file = 'p0_capabilities_demo/configs/p0_capabilities_demo_system_capabilities.yaml'
        if args.archive_root:
            args.spec = args.archive_root / ('experiments/pyrobosim/runs/pyrobosim_all_variants_alphabetic_once/runs/'
                'pyrobosim__p0_capabilities__p0_capabilities__one-hot__F__with_pending__alphabetic__seednone__threshold_250/'
                'trial_00/synthesis_byproducts/p0_capabilities.structuredslugs')
            args.capabilities = args.archive_root / capability_file
        else:
            args.spec = Path(__file__).with_name('p0-2fp-results') / 'archive_original/spec.structuredslugs'
            args.capabilities = (Path(__file__).resolve().parents[1] / 'p0_carriage'
                                 / 'capability-metadata' / capability_file)
        args.pair = ['grab_item_p=grab_item_a', 'move_robot_p=move_robot_a', 'place_item_p=place_item_a']
        if not args.capabilities.is_file():
            parser.error('Named case requires the archived P0 capability metadata')
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error('--timeout must be finite and positive')
    if bool(args.spec) != bool(args.pair):
        parser.error('--spec and explicit --pair mappings must be supplied together')
    for path in (args.slugs, args.compiler, *([args.spec] if args.spec else [])):
        if not path.is_file():
            parser.error(f'Not a file: {path}')
    cases = {'toy_original': toy(), 'toy_retry': toy(retry=True),
             'toy_forced_abandon_retry': toy(retry=True, abandon=True),
             'toy_forced_abandon_no_env_justice': toy(retry=True, abandon=True, justice=False)}
    metadata = {'slugs_sha256': hashlib.sha256(args.slugs.read_bytes()).hexdigest(),
                'compiler_sha256': hashlib.sha256(args.compiler.read_bytes()).hexdigest(),
                'named_case': args.case, 'timeout_per_process_s': args.timeout, 'pairs': args.pair, 'reorder_threshold': 250}
    if args.spec:
        source = args.spec.read_text()
        parts = parse(source)
        outputs = {line.split('#', 1)[0].strip() for line in parts['OUTPUT']}
        for pair in args.pair:
            pending, sep, activation = pair.partition('=')
            if not sep or pending not in outputs or not activation.strip() or '\n' in pair:
                parser.error(f'Invalid mapping: {pair!r}; pending must be a declared Boolean output')
            parts['SYS_LIVENESS'].append(f'(!{pending} | ({activation}))')
        cases['archive_original'] = source
        cases['archive_retry'] = render(parts)
        metadata.update(source=str(args.spec.resolve()), source_sha256=hashlib.sha256(source.encode()).hexdigest())
    args.out.mkdir(parents=True, exist_ok=False)
    summary = {'metadata': metadata, 'cases': {}, 'interpretation':
               'A realizable forced-abandonment case demonstrates that added system justice does not enforce retry unconditionally. The named P0 case additionally runs the structural auditor, not a fair-progress certification.'}
    failed = False
    for name, text in cases.items():
        directory = args.out / name
        directory.mkdir()
        source = directory / 'spec.structuredslugs'
        source.write_text(text)
        entry = {'sha256': hashlib.sha256(text.encode()).hexdigest()}
        summary['cases'][name] = entry
        compiled = run([sys.executable, str(args.compiler.resolve()), str(source.resolve())], directory / 'compile', args.timeout)
        entry['compile'] = compiled
        if compiled['status'] != 'finished' or compiled['returncode'] != 0:
            failed = True
            continue
        spec = directory / 'spec.slugsin'
        spec.write_bytes((directory / 'compile.stdout').read_bytes())
        entry['synthesis'] = run([str(args.slugs.resolve()), '--reorder-threshold', '250', '--explicitStrategy', '--jsonOutput', str(spec.resolve())], directory / 'synthesis', args.timeout)
        log = (directory / 'synthesis.stderr').read_text() + (directory / 'synthesis.stdout').read_text()
        entry['verdict'] = 'unknown'
        if entry['synthesis']['status'] == 'finished' and entry['synthesis']['returncode'] == 0:
            match = re.search(r'Specification is (unrealizable|realizable)', log)
            if match:
                entry['verdict'] = match[1]
        entry['well_separation'] = run([str(args.slugs.resolve()), '--reorder-threshold', '250', '--checkWellSeparation', '--minimizeWellSeparationCore', '--jsonOutput', str(spec.resolve()), str((directory / 'well_separation.json').resolve())], directory / 'well_separation', args.timeout)
        diagnostic = directory / 'well_separation.json'
        if diagnostic.exists():
            try:
                data = json.loads(diagnostic.read_text())
                entry['well_separation_verdict'] = data.get('status', 'unknown')
                entry['well_separation_cases'] = data.get('cases', [])
                failed |= not data.get('complete', False)
            except (ValueError, TypeError):
                failed = True
        else:
            failed = True
        if entry['verdict'] == 'realizable':
            try:
                strategy = json.loads((directory / 'synthesis.stdout').read_text())
                entry['strategy_states'] = len(strategy['nodes'])
                if name == 'toy_forced_abandon_retry':
                    witnesses = []
                    for node, record in strategy['nodes'].items():
                        valuation = dict(zip(strategy['variables'], record['state']))
                        if (valuation == {'c': 0, 'a': 0, 'p': 1, 'g': 0}
                                and str(node) in map(str, record['trans'])):
                            witnesses.append(node)
                    entry['abandonment_self_loop_nodes'] = witnesses
                    failed |= not witnesses
            except (ValueError, KeyError, TypeError):
                failed = True
        if args.case and name.startswith('archive_') and entry['verdict'] == 'realizable':
            entry['audit_process'] = run([sys.executable, str(Path(__file__).with_name('audit_p0.py').resolve()),
                '--source-root', str(args.auditor_root.resolve()), '--capabilities', str(args.capabilities.resolve()),
                '--directory', str(directory.resolve()), '--timeout', str(args.timeout)], directory / 'audit', args.timeout)
            failed |= entry['audit_process']['status'] != 'finished' or entry['audit_process']['returncode'] != 0
            for filename, key in [('audit.json', 'audit_result'), ('trap_analysis.json', 'trap_analysis')]:
                if (directory / filename).exists():
                    entry[key] = json.loads((directory / filename).read_text())
                else:
                    failed = True
        expected = 'unrealizable' if name == 'toy_forced_abandon_no_env_justice' else 'realizable'
        if name.startswith('toy_'):
            entry['expected'] = expected
            failed |= entry['verdict'] != expected
        failed |= entry['verdict'] == 'unknown' or entry['well_separation']['status'] != 'finished' or entry['well_separation']['returncode'] != 0
        print(name, entry['verdict'], flush=True)
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return int(failed)


if __name__ == '__main__':
    sys.exit(main())
