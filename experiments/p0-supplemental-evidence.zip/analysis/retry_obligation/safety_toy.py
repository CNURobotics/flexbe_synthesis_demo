#!/usr/bin/env python3
"""Toy-only comparison of justice retry and retry after one logging step."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

from probe import parse, render, run

BASE = '''[INPUT]
c
[OUTPUT]
a
p
g
log
[ENV_INIT]
!c
[SYS_INIT]
a
p
!g
!log
[ENV_TRANS]
c' -> a
[SYS_TRANS]
p' <-> (a' | (p & !c'))
g' <-> (g | c')
log' <-> (a & !c')
log' -> !a'
(g | c') -> !a'
[ENV_LIVENESS]
(!p | c')
[SYS_LIVENESS]
g
'''


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--slugs', type=Path, required=True)
    ap.add_argument('--compiler', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    summary = {'timeout_per_command_s': 30, 'reorder_threshold': 250,
               'slugs_sha256': hashlib.sha256(args.slugs.read_bytes()).hexdigest(),
               'compiler_sha256': hashlib.sha256(args.compiler.read_bytes()).hexdigest(),
               'cases': {}}
    failed = False
    for name in ('logging_justice', 'logging_safety', 'logging_safety_blocked', 'logging_safety_no_env_justice'):
        sections = parse(BASE)
        if name == 'logging_justice':
            sections['SYS_LIVENESS'].append('(!p | a)')
        else:
            # A failure enters one inactive logging step; this rule forces
            # reactivation on the next step while that attempt remains pending.
            sections['SYS_TRANS'].append("(p & !a) -> a'")
        if name == 'logging_safety_blocked':
            sections['SYS_TRANS'].append("log -> !a'")
        if name == 'logging_safety_no_env_justice':
            sections['ENV_LIVENESS'] = []
        folder = args.out / name
        folder.mkdir()
        source = folder / 'spec.structuredslugs'
        source.write_text(render(sections))
        entry = {'spec_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
        summary['cases'][name] = entry
        entry['compile'] = run([sys.executable, str(args.compiler.resolve()), str(source.resolve())], folder / 'compile', 30)
        if entry['compile']['status'] != 'finished' or entry['compile']['returncode'] != 0:
            failed = True
            continue
        spec = folder / 'spec.slugsin'
        spec.write_bytes((folder / 'compile.stdout').read_bytes())
        entry['synthesis'] = run([str(args.slugs.resolve()), '--reorder-threshold', '250', '--explicitStrategy', '--jsonOutput', str(spec.resolve())], folder / 'synthesis', 30)
        text = (folder / 'synthesis.stdout').read_text() + (folder / 'synthesis.stderr').read_text()
        match = re.search(r'Specification is (unrealizable|realizable)', text)
        entry['verdict'] = match[1] if match and entry['synthesis']['status'] == 'finished' and entry['synthesis']['returncode'] == 0 else 'unknown'
        entry['expected'] = 'realizable' if name in ('logging_justice', 'logging_safety') else 'unrealizable'
        failed |= entry['verdict'] != entry['expected']
        entry['well_separation'] = run([str(args.slugs.resolve()), '--reorder-threshold', '250', '--checkWellSeparation', '--minimizeWellSeparationCore', '--jsonOutput', str(spec.resolve()), str((folder / 'well_separation.json').resolve())], folder / 'well_separation', 30)
        if (folder / 'well_separation.json').exists():
            diag = json.loads((folder / 'well_separation.json').read_text())
            entry['well_separation_verdict'] = diag['status']
            entry['well_separation_cases'] = diag['cases']
            failed |= not diag['complete']
        else:
            failed = True
        failed |= entry['well_separation']['status'] != 'finished' or entry['well_separation']['returncode'] != 0
        if entry['verdict'] == 'realizable':
            strategy = json.loads((folder / 'synthesis.stdout').read_text())
            nodes = strategy['nodes']
            values = {n: dict(zip(strategy['variables'], r['state'])) for n, r in nodes.items()}
            reachable, todo = set(), ['0']
            while todo:
                n = todo.pop()
                if n not in reachable:
                    reachable.add(n)
                    todo.extend(str(t) for t in nodes[n]['trans'])
            idle = [n for n in reachable if values[n]['p'] and not values[n]['a']]
            violations = [(n, str(t)) for n in idle for t in nodes[n]['trans'] if not values[str(t)]['a']]
            entry['reachable_states'] = len(reachable)
            entry['pending_idle_states'] = sorted(idle)
            entry['retry_safety_violating_edges'] = violations
            entry['pending_idle_self_loops'] = [n for n in idle if n in map(str, nodes[n]['trans'])]
            if name == 'logging_safety':
                failed |= bool(violations) or not idle
                # Verify actual failure -> logging -> reactivation, not merely
                # the absence of a violating edge in an unexercised branch.
                paths = [(n, str(t), str(u)) for n in reachable if values[n]['a']
                         for t in nodes[n]['trans'] if not values[str(t)]['c']
                         for u in nodes[str(t)]['trans']
                         if values[str(t)]['log'] and not values[str(t)]['a'] and values[str(u)]['a']]
                entry['failure_log_retry_paths'] = paths
                failed |= not paths
        print(name, entry['verdict'], entry.get('well_separation_verdict'), flush=True)
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return int(failed)


if __name__ == '__main__':
    sys.exit(main())
