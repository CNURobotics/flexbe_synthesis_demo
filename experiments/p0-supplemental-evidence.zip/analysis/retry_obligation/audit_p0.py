#!/usr/bin/env python3
"""Adapt raw one-hot Slugs JSON to the installed auditor; summarize P0 traps."""
import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import sys

import yaml
from probe import parse


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--capabilities', type=Path, required=True)
    ap.add_argument('--directory', type=Path, required=True)
    ap.add_argument('--timeout', type=float, required=True)
    args = ap.parse_args()
    for package in ('flexbe_synthesis_core', 'flexbe_synthesis_slugs'):
        sys.path.insert(0, str(args.source_root / package))
    from flexbe_synthesis_core.graph_utils import tarjan_scc
    from flexbe_synthesis_slugs.helpers.strategy_auditor import StrategyAuditor

    folder = args.directory
    raw = json.loads((folder / 'synthesis.stdout').read_text())
    compiled = parse((folder / 'spec.slugsin').read_text())
    structured = parse((folder / 'spec.structuredslugs').read_text())
    clean = lambda lines: [s.split('#', 1)[0].strip() for s in lines
                           if s.split('#', 1)[0].strip()]
    inputs, outputs = clean(compiled['INPUT']), clean(compiled['OUTPUT'])
    assert set(raw['variables']) == set(inputs + outputs)
    assert '0' in raw['nodes'] and 'finished' in outputs
    values = {str(n): dict(zip(raw['variables'], record['state']))
              for n, record in raw['nodes'].items()}
    adjacency = {str(n): [str(t) for t in record['trans']]
                 for n, record in raw['nodes'].items()}
    assert all(len(r['state']) == len(raw['variables']) for r in raw['nodes'].values())
    assert all(t in values for targets in adjacency.values() for t in targets)
    incoming = {t for targets in adjacency.values() for t in targets}
    roots = [n for n in raw['nodes'] if n not in incoming and adjacency[n]]
    # Match SlugsSynthesizerHelper: first root with outgoing transitions.
    assert roots and roots[0] == '0'
    states = []
    for n, record in raw['nodes'].items():
        v = values[n]
        states.append({'name': n, 'transitions': adjacency[n], 'rank': record['rank'],
                       'is_initial': n == '0',
                       'input_variables': [x for x in inputs if v[x]],
                       'output_variables': [x for x in outputs if v[x]],
                       'input_values': {x: v[x] for x in inputs},
                       'output_values': {x: v[x] for x in outputs}})
    capabilities = yaml.safe_load(args.capabilities.read_text())
    # Fail rather than silently drop a capability or invent outcome metadata.
    assert {name + '_a' for name in capabilities['capabilities']} == {x for x in outputs if x.endswith('_a')}
    result = StrategyAuditor(timeout_s=args.timeout).audit(
        {'automaton': states, 'input_variables': inputs, 'output_variables': outputs},
        str(folder / 'spec.slugsin'), capabilities, {},
        {'env_trans': structured['ENV_TRANS'], 'sys_props': outputs}, ['finished'])
    (folder / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')

    # P0 has a persistent terminal goal. Reverse reachability to finished is
    # therefore sufficient to identify its goal-unreachable region; this is
    # descriptive graph analysis, not a general fair-progress checker.
    reachable, queue = {'0'}, deque(['0'])
    parent = {'0': None}
    while queue:
        n = queue.popleft()
        for t in adjacency[n]:
            if t not in reachable:
                reachable.add(t)
                parent[t] = n
                queue.append(t)
    reverse = {n: [] for n in reachable}
    for n in reachable:
        for t in adjacency[n]:
            reverse[t].append(n)
    goals = {n for n in reachable if values[n]['finished']}
    assert all(values[t]['finished'] for n in goals for t in adjacency[n])
    can_finish, queue = set(goals), deque(goals)
    while queue:
        for n in reverse[queue.popleft()]:
            if n not in can_finish:
                can_finish.add(n)
                queue.append(n)
    traps = []
    for component in tarjan_scc(sorted(reachable), adjacency):
        if len(component) == 1 and component[0] not in adjacency[component[0]]:
            continue
        if any(n in can_finish for n in component):
            continue
        abandoned = []
        for p in ('grab_item_p', 'move_robot_p', 'place_item_p'):
            a, c = p[:-2] + '_a', p[:-2] + '_c'
            if all(values[n][p] and not values[n][a] and not values[n][c] for n in component):
                abandoned.append(p[:-2])
        target = sorted(component)[0]
        path = []
        while target is not None:
            path.append(target)
            target = parent[target]
        traps.append({'states': sorted(component),
                      'closed': all(t in component for n in component for t in adjacency[n]),
                      'persistently_pending_inactive_uncompleted': abandoned,
                      'path_from_initial': list(reversed(path))})
    analysis = {'initial_state': '0', 'extracted_states': len(values),
                'alternative_roots': roots[1:],
                'roots_have_identical_successors': len({tuple(adjacency[n]) for n in roots}) == 1, 'reachable_states': len(reachable),
                'goal_states': len(goals), 'goal_unreachable_states': len(reachable - can_finish),
                'trap_scc_count': len(traps), 'traps': traps,
                'source_hashes': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (
                    args.capabilities,
                    args.source_root / 'flexbe_synthesis_slugs/flexbe_synthesis_slugs/helpers/strategy_auditor.py',
                    args.source_root / 'flexbe_synthesis_slugs/flexbe_synthesis_slugs/helpers/slugs_automaton.py',
                    args.source_root / 'flexbe_synthesis_core/flexbe_synthesis_core/graph_utils.py')}}
    (folder / 'trap_analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
    print(result['failure_kind'], 'trap SCCs:', len(traps), flush=True)
    return int(result.get('incomplete', False) or result['failure_kind'] in ('PARSE_ERROR', 'SPEC_EVAL_ERROR')
               or any('Protocol enforcement disabled' in w for w in result['warnings']))


if __name__ == '__main__':
    sys.exit(main())
