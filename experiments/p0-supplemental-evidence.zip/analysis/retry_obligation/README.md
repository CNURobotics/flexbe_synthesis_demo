# Targeted retry-obligation probe

These supplemental experiments test whether a system justice clause requiring
retry while a capability is pending prevents abandonment under GR(1)
assume–guarantee semantics. The controls use a single-capability model. The
Coffee and PyRoboSim P0 comparisons use archived experiment inputs.

## Run

Run from the directory containing `p0_carriage/` and `retry_obligation/`.
Set `SLUGS_ROOT` to the Slugs checkout used to build the solver. The semantic
controls need only Python and Slugs.

```sh
python3 retry_obligation/probe.py --out /tmp/retry-probe-new \
  --slugs "$SLUGS_ROOT/src/slugs" \
  --compiler "$SLUGS_ROOT/tools/StructuredSlugsParser/compiler.py"
```

Use the bundled original extended Coffee alphabetic one-hot
Fair-Outcome-with-pending input to rerun the domain pair alongside the
controls.

```sh
python3 retry_obligation/probe.py --out /tmp/retry-coffee-new \
  --slugs "$SLUGS_ROOT/src/slugs" \
  --compiler "$SLUGS_ROOT/tools/StructuredSlugsParser/compiler.py" \
  --spec retry_obligation/coffee-3fp-results/archive_original/spec.structuredslugs \
  --pair bd_p=bd_a --pair br_p=br_a --pair gr_p=gr_a
```

Each mapping adds `(!pending | (activation))` to `SYS_LIVENESS`, where Slugs
implicitly applies `GF`. Supply every intended pending capability explicitly;
the script does not infer mappings or certify that the input uses Fair-Outcome.
For enumerated encodings the activation may be an expression such as
`--pair 'move_p=capability=7'`. Use the declaration and action index from the
input specification. The script checks that the pending variable is declared
as a Boolean output.

Defaults: `~/slugs/src/slugs`,
`~/slugs/tools/StructuredSlugsParser/compiler.py`, threshold 250, and a
30-second timeout **per subprocess**. Override paths with `--slugs` and
`--compiler`, and the budget with `--timeout`. There are four toy cases and,
with `--spec`, two archive cases; each has compilation, extraction, and
well-separation/core-minimization commands. Thus six cases have a conservative
18 × timeout subprocess budget, not a single 30-second overall budget.

Outputs include generated structured/compiled specs, explicit strategies,
well-separation JSON, stdout/stderr, exact commands, input/tool hashes, timing,
and `summary.json`. A nonzero exit reports an error/unknown result or a failed
toy expectation; a timeout is never classified as unrealizability. An existing
output directory is rejected. The script performs no full auditor or fair-path
verification and makes no performance-comparison claim.

## Semantic controls

One capability is initially active and pending. Environment completion `c` is
activation-gated; pending `p` persists until completion; goal `g` persists after
completion. The original assumption is `GF(!p | X c)` and the goal is `GF g`.
The proposed addition is `GF(!p | a)`.

The forced-abandonment control additionally requires `!X a`. After an initial
noncompletion, the legal trace stays at `c=0, a=0, p=1, g=0`. Both environment
justice and retry justice fail there, so the assume–guarantee implication is
satisfied. The script checks for that self-loop in the extracted strategy.
Removing environment justice supplies a negative control: forced abandonment
can no longer win, since the environment may refuse the initial completion.
This is a semantic counterexample, not a claim that all domain controllers
choose abandonment.

## October 28 results

The run used Slugs revision `4d2edb5`. The compiler and solver hashes,
input hash, commands and results are in [oct28-results.json](oct28-results.json).
All commands completed within the per-process budget. Archived command and
source records use placeholders for machine-specific directory prefixes.

| Case | Realizability | Well-separation | Strategy states |
| --- | --- | --- | --- |
| Toy original | Realizable | NWS, P-all/E-just | 4 |
| Toy + retry justice | Realizable | NWS, P-all/E-just | 4 |
| Toy + retry justice + forced abandonment | Realizable | NWS, P-all/E-just | 4 |
| Forced abandonment, no environment justice | Unrealizable | Well-separated | — |
| Archived extended Coffee original | Realizable | NWS, P-all/E-just | 7 |
| Same Coffee + three retry obligations | Realizable | NWS, P-all/E-just | 7 |

The saved [forced-abandonment witness](oct28-abandonment-witness.json) contains
initial node 0, whose noncompletion successor is node 1; node 1 is the
`c=0, a=0, p=1, g=0` self-loop. This directly refutes the general assertion that
adding this system justice clause prevents abandonment under ordinary
assume–guarantee semantics. Non-well-separation by itself is not the proof.
Both Coffee variants have the same realizability status, diagnostic case,
and extracted state count. The raw [original](coffee-3fp-results/archive_original/synthesis.stdout)
and [retry](coffee-3fp-results/archive_retry/synthesis.stdout) outputs also
have identical variables, state valuations, and transitions. Their compiled
and structured inputs are saved alongside them.

## PyRoboSim P0 2FP, alphabetic ordering

The named case adds all three pending-capability obligations (grab, move,
place) and runs the existing strategy auditor on each extracted strategy:

```sh
python3 retry_obligation/probe.py --case p0-2fp \
  --auditor-root "$FLEXBE_SYNTHESIS_ROOT" \
  --slugs "$SLUGS_ROOT/src/slugs" \
  --compiler "$SLUGS_ROOT/tools/StructuredSlugsParser/compiler.py" \
  --timeout 600 --out /tmp/p0-2fp-retry-new
```

Set `FLEXBE_SYNTHESIS_ROOT` to the FlexBE synthesis checkout in your sourced
ROS workspace. The named case uses the bundled alphabetic one-hot
Fair-Outcome-with-pending, threshold-250 spec and its archived capability
metadata by default. Its structured specification is byte-identical (SHA-256
`10c2c4bdd1c918b9dca246e61714d5805e8f2cce9404da3a418de2111dae1497`)
to the corresponding `pyrobosim_stats` trial. The intervention appends three
system justice clauses.

The audit worker requires PyYAML and imports the FlexBE synthesis helper
modules directly. It uses the archived capability/outcome metadata, the compiled
input/output partition, and initial node 0 of the Slugs explicit-strategy output. It
rejects a capability-declaration mismatch or disabled strict protocol checking.
The audit is separately bounded by the subprocess timeout as well as the
helper's own time budget. The named case has two additional audit subprocesses
beyond the generic probe's 18 commands; the 600-second limit is per command,
not a prediction of total runtime.

Each archive case also produces `audit.json` and `trap_analysis.json`, with
all reachable cyclic SCCs unable to reach `finished`, their closed/open status,
paths from the initial state, and capabilities whose pending flag stays true
while activation and completion stay false throughout that SCC. This graph
summary is specific to P0's persistent terminal goal, whose persistence is
checked. It is not the insufficient “an SCC contains a goal” recurrence test,
and it does not claim fairness-aware progress certification. Source hashes
record the actual auditor, graph helper, automaton helper, and capability YAML.

Adapter validation against the older saved strategy in the selected archive
reproduces `GOAL_UNREACHABLE_TRAP`, with no warnings and twelve trap SCCs.
Both archived copies have 108 extracted nodes, of which 89 are reachable from
the pipeline-selected initial node 0. The other nineteen are alternative roots
with the same successors. The adapter follows `SlugsSynthesizerHelper` in
selecting the first root with outgoing transitions and verifies that it is
node 0. Extracted and reachable node counts are reported separately. Compare
the newly generated original/modified pair under one binary and flag set;
historical node identifiers are not invariants of a specification.

### P0 results — October 28, 2026

Both runs completed within the 600-second per-process limit, using the same
Slugs binary/compiler hashes as the earlier Coffee probe. Full specs, solver
outputs, diagnostics, audits, and trap summaries are preserved in
[p0-2fp-results](p0-2fp-results/summary.json).

| Measure | Original P0 2FP | With three retry obligations |
| --- | --- | --- |
| Realizability | Realizable | Realizable |
| Well-separation | NWS: P-reach/E-safe and P-all/E-just | Same |
| Extracted nodes / reachable from selected root | 108 / 89 | 108 / 89 |
| Strict auditor | GOAL_UNREACHABLE_TRAP | GOAL_UNREACHABLE_TRAP |
| Audit incomplete / warnings | False / none | False / none |
| Goal-unreachable reachable states | 66 | 66 |
| Trap SCCs / closed trap SCCs | 12 / 4 | 12 / 4 |
| Synthesis and extraction subprocess wall time | 228.336 s | 228.203 s |

The timing is a single-run observation, not evidence of a speed difference.
The variable order, node valuations, and transitions are identical; only one
node's liveness-rank annotation differs. Both graphs contain the paper's
closed component `{72, 73, 83}`: throughout it, `move_robot_p=1`,
`move_robot_a=0`, `move_robot_c=0`, and `finished=0`. Transitions are
`72 -> 83`, `73 -> {72,73}`, and `83 -> {72,73}`. The trap is reachable along
`0,20,22,24,27,30,36,46,53,63,72`. Thus the pending-move justice assumption and
the added move-retry justice obligation are both violated on an infinite
execution inside this component; their placement under the assume–guarantee
implication permits the strategy to remain winning.

**Conclusion for this case:** adding the proposed retry obligations does not
repair the illustrated trap or change the controller's transition behavior.
The strict audit and the explicit witness establish that the trap persists
in this extracted strategy pair.

## Safety-level retry toy model

```sh
python3 retry_obligation/safety_toy.py --out /tmp/safety-retry-new \
  --slugs "$SLUGS_ROOT/src/slugs" \
  --compiler "$SLUGS_ROOT/tools/StructuredSlugsParser/compiler.py"
```

The four cases use the toy specification, a 30-second timeout per subprocess,
and CUDD threshold 250. The initial capability is active and pending.
Completion is environment-controlled and activation-gated. Noncompletion
forces exactly one inactive logging state. A completion sets the persistent
goal and clears pending when the capability stops.

The justice version adds `GF(!p | a)` to system liveness. The safety version
instead adds `G((p & !a) -> X a)` to system safety, expressed without the outer
`G` in `SYS_TRANS`. This allows the logging step but forces activation next.
This is a one-capability toy, with no competing pending tasks, unavailable
reactivation preconditions, explicit abort action, or physical timing claim.

The command writes the following results to `summary.json` in the output
directory alongside the specifications, solver logs, strategies and diagnostics.

| Case | Realizability | Extracted behavior / control |
| --- | --- | --- |
| Logging + justice retry | Realizable | Five reachable states; pending/inactive self-loop at node 3 permits abandonment. |
| Logging + safety retry | Realizable | Four reachable states; failure path `0 -> 1 -> 0` activates, logs, then retries; no reachable edge violates the retry rule. |
| Safety retry + `log -> !X a` | Unrealizable | Deliberately conflicting next-step availability prevents required reactivation after a failure. |
| Safety retry without environment justice | Unrealizable | The environment can refuse completion forever, despite repeated activation. |

The first three specifications remain NWS (`P-all/E-just`); removing environment
justice yields well-separated status in the last case. The diagnostic is not
an assertion that the extracted safety-constrained strategy abandons the task.
The direct edge check, not NWS, establishes that this strategy respects the
bounded retry rule. An infinite failure/log/retry execution is still possible
but violates the environment's completion justice; this test does not prove
unconditional completion.

These results apply to the single-capability model with its fixed logging
step and reactivation rule.
