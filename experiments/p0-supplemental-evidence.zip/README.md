# Supplemental evidence for the FlexBE synthesis preprint

This archive accompanies arXiv:2609.30460 v2. The September experiment
data remain in the separate release archive at commit `e7991e65`.

- [P0 carriage-constraint comparison](analysis/p0_carriage/PAIRED_RUNS.md)
  covers all seven production-mode pairs. Its Python replay compares the
  bundled outputs without ROS or Slugs.
- [Coffee and P0 retry-justice checks](analysis/retry_obligation/README.md)
  describe both matched pairs. Their input specifications and extracted
  strategies are bundled under `coffee-3fp-results/` and `p0-2fp-results/`.

The run reports give explicit commands for a sourced ROS workspace.
Supply the FlexBE synthesis checkout and Slugs tools from that workspace.
Archived provenance uses path placeholders. The bundled specifications
and extracted strategies preserve the original experiment contents.
