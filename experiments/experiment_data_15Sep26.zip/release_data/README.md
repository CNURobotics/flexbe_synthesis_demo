# Release Data

This folder contains the exported experiment data used for the paper tables.
Each domain subdirectory contains:

- `master.csv`: per-trial results
- `summary.csv`: aggregate results derived from `master.csv`

The exported CSVs have local home-directory paths and hostnames scrubbed. The
machine information for the canonical run is in `computer.txt`.

Generated LaTeX tables and plots are intentionally not included. They can be
regenerated from the CSVs with the postprocess tool shipped by
`flexbe_synthesis`.

## Requirements

Run these commands from a sourced ROS workspace that includes
`flexbe_synthesis`, so that either of these works:

```bash
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess --help
slugs_experiment_postprocess --help
```

## Regenerate summaries, diagnostic tables, and plots

From this `release_data` directory:

```bash
for d in coffee two_rivers pyrobosim_p0 pyrobosim_p1 crazyflie crazyflie_fair_outcome_pending; do
  python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
    --run-dir "$d" \
    --refresh-summary \
    --summary-plot \
    --plot-format pdf \
    --plot-format png \
    --no-paper-tables
done
```

This rewrites each `summary.csv` from `master.csv`, writes a diagnostic
`tables/cudd_peak_nodes_mean.tex`, and writes plots under each domain's
`plots/` directory.

## Regenerate paper-style LaTeX tables

Most domains can use the default paper-table selection, but the P1 and
Fair-Outcome/pending Crazyflie subsets are single fixed-ordering runs and need
explicit table-selection flags.

```bash
# Coffee: split by encoding, full and compact forms.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir coffee --no-plots --split-encoding-tables --split-prefix coffee
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir coffee --no-plots --split-encoding-tables --split-prefix coffee --compact

# Two-Rivers: combined table, full and compact forms.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir two_rivers --no-plots
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir two_rivers --no-plots --compact

# PyRoboSim P0: combined full table, split compact tables.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir pyrobosim_p0 --no-plots
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir pyrobosim_p0 --no-plots --split-encoding-tables --split-prefix pyrobosim_p0 --compact

# PyRoboSim P1: fixed alphabetic ordering with uncapped CUDD reordering.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir pyrobosim_p1 --no-plots --table-policy auto --table-ordering alphabetic
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir pyrobosim_p1 --no-plots --table-policy auto --table-ordering alphabetic --compact

# Crazyflie main sweep: combined table, full and compact forms.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir crazyflie --no-plots
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir crazyflie --no-plots --compact

# Crazyflie Fair-Outcome/pending subset: fixed alphabetic ordering.
python3 -m flexbe_synthesis_slugs.helpers.experiment_postprocess \
  --run-dir crazyflie_fair_outcome_pending \
  --no-plots \
  --table-policy threshold_250 \
  --table-ordering alphabetic
```

The paper repository applies a small amount of additional presentation logic
when copying these generated tables into the manuscript, such as extracting
only the `tabular` body and relabeling PyRoboSim P1's one-hot column header for
paper consistency. Those manuscript-specific steps live in the paper repo, not
in this release-data bundle.
